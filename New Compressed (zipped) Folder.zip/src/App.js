import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BrowserRouter as Router, Route, Routes, useNavigate } from 'react-router-dom';
import './styles.css';

function ValentinePrompt() {
  const [noPosition, setNoPosition] = useState({ top: '50%', left: '50%' });
  const [hearts, setHearts] = useState(
    Array.from({ length: 70 }, () => ({ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight }))
  );
  const [butterflies, setButterflies] = useState(
    Array.from({ length: 20 }, () => ({ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight }))
  );
  const navigate = useNavigate();

  const moveNoButton = () => {
    const randomTop = Math.random() * 80 + '%';
    const randomLeft = Math.random() * 80 + '%';
    setNoPosition({ top: randomTop, left: randomLeft });
  };

  useEffect(() => {
    const moveElements = () => {
      setHearts(hearts.map(() => ({ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight })));
      setButterflies(butterflies.map(() => ({ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight })));
    };

    const interval = setInterval(moveElements, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="container animated-gradient">
      <h1 className="title animated-text">Sequoia, will you be my Valentine?</h1>

      <div className="button-group">
        <motion.button
          className="yes-button pulse"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 1, repeat: Infinity }}
          onClick={() => navigate('/yes')}
        >
          Yes ❤️
        </motion.button>

        <motion.button
          onMouseEnter={moveNoButton}
          style={{ top: noPosition.top, left: noPosition.left }}
          className="no-button escape"
          whileHover={{ scale: 1.1 }}
        >
          No 💔
        </motion.button>
      </div>

      {hearts.map((heart, index) => (
        <motion.div
          key={index}
          className="heart"
          style={{ left: heart.x, top: heart.y }}
          animate={{ y: [heart.y, heart.y - 20, heart.y] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          💕
        </motion.div>
      ))}

      {butterflies.map((butterfly, index) => (
        <motion.div
          key={index}
          className="butterfly"
          style={{ left: butterfly.x, top: butterfly.y }}
          animate={{
            x: [butterfly.x, butterfly.x + (Math.random() * 50 - 25), butterfly.x],
            y: [butterfly.y, butterfly.y - 30, butterfly.y]
          }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        >
          🦋
        </motion.div>
      ))}
    </div>
  );
}

function YesPage() {
  const [hearts, setHearts] = useState(
    Array.from({ length: 50 }, () => ({ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight }))
  );

  useEffect(() => {
    const audio = new Audio(`${process.env.PUBLIC_URL}/song.mp3`);
    audio.play().catch((error) => console.log("Autoplay blocked:", error));
  }, []);

  return (
    <div className="yes-page animated-gradient">
      <h1 className="title animated-text">Yay! ❤️</h1>
      <p className="subtitle paragraph-text">
        I can’t wait to spend Valentine’s Day with you, Sequoia! I couldn’t imagine a better Valentine than you! 
        I can’t wait to spend this Valentine’s Day (and so many more) making you smile, making memories, and reminding 
        you how much you mean to me. Thank you for being my Valentine--now and forever, my love.
      </p>
      <img src={`${process.env.PUBLIC_URL}/valentine.jpeg`} alt="Valentine" className="valentine-image small-image" />

      {hearts.map((heart, index) => (
        <motion.div
          key={index}
          className="heart"
          style={{ left: heart.x, top: heart.y }}
          animate={{ y: [heart.y, heart.y - 20, heart.y] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          💕
        </motion.div>
      ))}
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<ValentinePrompt />} />
        <Route path="/yes" element={<YesPage />} />
      </Routes>
    </Router>
  );
}












